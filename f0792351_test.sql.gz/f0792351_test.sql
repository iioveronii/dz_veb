-- MySQL dump 10.13  Distrib 5.7.37-40, for Linux (x86_64)
--
-- Host: localhost    Database: f0792351_test
-- ------------------------------------------------------
-- Server version	5.7.37-40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*!50717 SELECT COUNT(*) INTO @rocksdb_has_p_s_session_variables FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'performance_schema' AND TABLE_NAME = 'session_variables' */;
/*!50717 SET @rocksdb_get_is_supported = IF (@rocksdb_has_p_s_session_variables, 'SELECT COUNT(*) INTO @rocksdb_is_supported FROM performance_schema.session_variables WHERE VARIABLE_NAME=\'rocksdb_bulk_load\'', 'SELECT 0') */;
/*!50717 PREPARE s FROM @rocksdb_get_is_supported */;
/*!50717 EXECUTE s */;
/*!50717 DEALLOCATE PREPARE s */;
/*!50717 SET @rocksdb_enable_bulk_load = IF (@rocksdb_is_supported, 'SET SESSION rocksdb_bulk_load = 1', 'SET @rocksdb_dummy_bulk_load = 0') */;
/*!50717 PREPARE s FROM @rocksdb_enable_bulk_load */;
/*!50717 EXECUTE s */;
/*!50717 DEALLOCATE PREPARE s */;

--
-- Table structure for table `Voprosi`
--

DROP TABLE IF EXISTS `Voprosi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Voprosi` (
  `nomer` int(11) NOT NULL AUTO_INCREMENT,
  `vopros` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `otvet` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `nomer_varianta` int(11) NOT NULL,
  PRIMARY KEY (`nomer`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Voprosi`
--

LOCK TABLES `Voprosi` WRITE;
/*!40000 ALTER TABLE `Voprosi` DISABLE KEYS */;
INSERT INTO `Voprosi` (`nomer`, `vopros`, `otvet`, `nomer_varianta`) VALUES (2,'Как называются данные или программа на магнитном диске?','Файл',1),(3,'Какие символы разрешается использовать в имени файла или имени директории в Windows?','Латинские, русские букву и цифры',1),(4,'Выберите имя файла anketa с расширением txt.','Anketa. txt',2),(5,'Укажите неправильное имя каталога.','CD\\MAN',2),(6,'2+2','4',2),(7,'1','1',1),(8,'5+5','10',1),(9,'1','1',1),(10,'кто проживает на дне океана','губка боб квадратные штаны',2),(12,'','',0),(13,'','',0);
/*!40000 ALTER TABLE `Voprosi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `message_text` text COLLATE utf8_unicode_ci NOT NULL,
  `pub_time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messages`
--

LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
INSERT INTO `messages` (`id`, `message_text`, `pub_time`) VALUES (9,'cool','2023-03-29 15:00:41');
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ponatia`
--

DROP TABLE IF EXISTS `ponatia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ponatia` (
  `nomer` int(11) NOT NULL AUTO_INCREMENT,
  `ponatie` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `opredelenie` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `razdel_disciplini` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `primeri` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `illustracia_primerov` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`nomer`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ponatia`
--

LOCK TABLES `ponatia` WRITE;
/*!40000 ALTER TABLE `ponatia` DISABLE KEYS */;
INSERT INTO `ponatia` (`nomer`, `ponatie`, `opredelenie`, `razdel_disciplini`, `primeri`, `illustracia_primerov`) VALUES (1,'Алгоритм','Алгоритм – это набор инструкций или правил, предназначенных для решения определенной проблемы.','Программирование','Сбор ягод в корзину.','3.jpg'),(2,'Ошибка','Ошибка – это общий термин, используемый для обозначения непредвиденной ошибки или дефекта в аппаратном или программном обеспечении, что приводит к его неисправности.','Программирование','Ошибка при делении на ноль.','5.png'),(3,'Искусственный интеллект','Искусственный интеллект — это область науки, занимающаяся моделированием интеллектуальной деятельности человека.','Искусственный интеллект','Навигатор','6.jpg'),(4,'Искусственный нейрон','Искусственный нейрон — это математическая функция, задуманная как модель биологических нейронов, нейронной сети.','Искусственный интеллект','Персептрон','4.png'),(5,'Информация','Информация – это продукт взаимодействия данных и методов, рассмотренный в контексте этого взаимодействия.','Прикладная информатика','Чтение книги','2.jpg'),(18,'Программирование','Программирование — процесс создания компьютерных программ.','Программирование','Обработка строк','7.jpg'),(20,'Программирование','Программирование — процесс создания компьютерных программ.','Программирование','Обработка строк','7.jpg');
/*!40000 ALTER TABLE `ponatia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `pas` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `login`, `pas`) VALUES (3,'log','123'),(4,'1','1'),(5,'',''),(6,'1','1');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'f0792351_test'
--
/*!50112 SET @disable_bulk_load = IF (@is_rocksdb_supported, 'SET SESSION rocksdb_bulk_load = @old_rocksdb_bulk_load', 'SET @dummy_rocksdb_bulk_load = 0') */;
/*!50112 PREPARE s FROM @disable_bulk_load */;
/*!50112 EXECUTE s */;
/*!50112 DEALLOCATE PREPARE s */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-03 16:49:03
